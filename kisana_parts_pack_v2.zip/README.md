# Kisàna Parts Pack v2 (no Photoshop needed)
This pack contains 1024x1024 transparent PNG layers extracted from the final base image.
All parts keep the original canvas size so they align when stacked.

## Files
- kisana_base_1024.png : base reference
- parts_png/head_hair.png
- parts_png/torso.png
- parts_png/arm_left.png
- parts_png/arm_right.png
- parts_png/legs.png
- parts_png/boots.png

## How to use without Photoshop
- Any image viewer/editor that supports layers can stack these (e.g., Krita/GIMP/Photopea).
- For DST/Spriter, import each PNG as a separate sprite; they already share the same origin.
