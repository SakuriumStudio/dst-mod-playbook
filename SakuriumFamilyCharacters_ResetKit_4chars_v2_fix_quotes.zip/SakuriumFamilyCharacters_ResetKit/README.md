# Sakurium Family Characters - Reset Kit (4 characters)

目的: まず **落ちない / 透明にならない(仮: wilson見た目借り)** 状態で、家族4キャラを選択できるテンプレに戻す。

## First Run (必須)
1. Steam の「ツール」で **Don't Starve Mod Tools** をインストール
2. このMODフォルダ内 `tools\02_compile_textures.bat` を実行（autocompiler 起動）
3. autocompiler を起動したまま DST を起動して、このMODを有効化

> PNGはゲームが直接読めません。autocompilerが `.tex` / `.xml` を生成します。

## 今日のゴール
- キャラ選択画面で 4人が表示される
- どれを選んでもワールドにスポーンして操作できる

## 次の段階
- 各 `scripts/prefabs/<name>.lua` の `master_postinit` に能力/数値を追加
- 最終的に自作見た目にする場合は `anim/<name>.zip` と `anim/ghost_<name>_build.zip` を用意
