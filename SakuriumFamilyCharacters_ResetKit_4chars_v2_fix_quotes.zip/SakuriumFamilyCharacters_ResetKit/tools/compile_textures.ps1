#requires -version 5.1
<#
Compile PNG -> TEX/XML for DST mods using Klei autocompiler.

What this does:
- Locate Steam library folders
- Find "Don't Starve Mod Tools" install
- Launch autocompiler.exe (keeps running)
- Wait until key .tex files appear for this mod

Notes:
- autocompiler is designed assuming the mod tools live alongside the game install structure.
  If it instantly closes, install "Don't Starve Mod Tools" on the SAME DRIVE as DST. 
#>

$ErrorActionPreference = "Stop"

function Get-SteamLibraryFolders {
    $paths = New-Object System.Collections.Generic.List[string]

    $steamRoot = "${env:ProgramFiles(x86)}\Steam"
    if (-not (Test-Path $steamRoot)) { $steamRoot = "${env:ProgramFiles}\Steam" }
    if (Test-Path $steamRoot) { $paths.Add($steamRoot) }

    $vdf = Join-Path $steamRoot "steamapps\libraryfolders.vdf"
    if (Test-Path $vdf) {
        $txt = Get-Content $vdf -Raw
        # Pull out "path" entries
        foreach ($m in [regex]::Matches($txt, '"path"\s*"([^"]+)"')) {
            $p = $m.Groups[1].Value -replace "\\", "\"
            if (Test-Path $p) { $paths.Add($p) }
        }
    }
    # De-dup
    return $paths | Select-Object -Unique
}

function Find-Autocompiler {
    param([string[]]$Libraries)

    $candidates = New-Object System.Collections.Generic.List[string]
    foreach ($lib in $Libraries) {
        $common = Join-Path $lib "steamapps\common"
        if (-not (Test-Path $common)) { continue }

        $dstTools = Join-Path $common "Don't Starve Mod Tools"
        if (Test-Path $dstTools) {
            # Common known locations
            $likely = @(
                (Join-Path $dstTools "mod_tools\autocompiler.exe"),
                (Join-Path $dstTools "mod_tools\tools\autocompiler.exe"),
                (Join-Path $dstTools "tools\autocompiler.exe")
            )
            foreach ($p in $likely) { if (Test-Path $p) { return $p } }

            # Fallback: search within mod tools folder (limited)
            $found = Get-ChildItem -Path $dstTools -Filter autocompiler.exe -Recurse -ErrorAction SilentlyContinue |
                     Select-Object -ExpandProperty FullName -First 1
            if ($found) { return $found }
        }
    }
    return $null
}

function Wait-ForTex {
    param(
        [string]$ModDir,
        [int]$TimeoutSec = 90
    )
    $targets = @(
        (Join-Path $ModDir "images\saveslot_portraits\kisana.tex"),
        (Join-Path $ModDir "images\selectscreen_portraits\kisana.tex"),
        (Join-Path $ModDir "bigportraits\kisana.tex"),
        (Join-Path $ModDir "images\avatars\avatar_kisana.tex")
    )
    $t0 = Get-Date
    while ((Get-Date) - $t0 -lt [TimeSpan]::FromSeconds($TimeoutSec)) {
        $ok = $true
        foreach ($f in $targets) { if (-not (Test-Path $f)) { $ok = $false; break } }
        if ($ok) { return $true }
        Start-Sleep -Milliseconds 500
    }
    return $false
}

$modDir = Split-Path -Parent $PSScriptRoot  # ...\SakuriumFamilyCharacters_ResetKit
Write-Host "[ResetKit] Mod dir: $modDir"

$libraries = Get-SteamLibraryFolders
$auto = Find-Autocompiler -Libraries $libraries
if (-not $auto) {
    Write-Warning "autocompiler.exe が見つかりません。Steamの『ツール』から『Don't Starve Mod Tools』をインストールしてください。"
    Write-Host "ヒント: 例) X:\SteamLibrary\steamapps\common\Don't Starve Mod Tools\mod_tools\autocompiler.exe"
    exit 1
}

Write-Host "[ResetKit] autocompiler: $auto"
Write-Host "[ResetKit] autocompiler を起動します（閉じずに起動したままにしてOK）"
Start-Process -FilePath $auto -WorkingDirectory (Split-Path $auto)

Write-Host "[ResetKit] PNG -> TEX/XML が生成されるまで待機します..."
if (Wait-ForTex -ModDir $modDir -TimeoutSec 120) {
    Write-Host "[ResetKit] OK: 必要な .tex が生成されました。DSTを起動してテストしてOKです。"
    exit 0
} else {
    Write-Warning "時間内に .tex が生成されませんでした。"
    Write-Host "チェック:"
    Write-Host " - autocompiler が起動し続けているか（即終了する場合は Mod Tools をDSTと同じドライブに入れる必要があることがあります）"
    Write-Host " - このMODフォルダが DST の mods フォルダ直下にあるか"
    exit 2
}
