local MakePlayerCharacter = require "prefabs/player_common"
local Visual = require "sakurium_visual"

local assets = { }
local prefabs = { }

local start_inv = { }

local function common_postinit(inst)
    inst:AddTag("sakurium_family")
    -- 透明化回避: 既存キャラの見た目を借りる（まずはwilson固定）
    Visual.InstallBorrowedLookHooks(inst, "wilson")
end

local function master_postinit(inst)
    inst.soundsname = "wilson"
    inst.talker_path_override = "speech_wilson"

    -- 仮ステータス（後で各キャラ固有に変更）
    inst.components.health:SetMaxHealth(150)
    inst.components.hunger:SetMax(150)
    inst.components.sanity:SetMax(200)

    Visual.InstallBorrowedLookHooks(inst, "wilson")
end

return MakePlayerCharacter("yuki", prefabs, assets, common_postinit, master_postinit, start_inv)
