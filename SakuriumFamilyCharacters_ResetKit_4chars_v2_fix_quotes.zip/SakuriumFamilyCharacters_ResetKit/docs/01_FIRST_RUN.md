# 01_FIRST_RUN: 最初にやること（1回だけ）

このMODは、配布物に **.tex / .xml（コンパイル済みテクスチャ）** を含めません。
代わりに **PNG素材** を同梱しています。

DSTはそのままではPNGを読めないので、**最初に PNG→TEX/XML 変換（コンパイル）** が必要です。

## 手順（推奨: Mod Tools / autocompiler）

1. Steamで **Don't Starve Mod Tools** をインストール
2. Mod Tools 内の **autocompiler** を起動（または tools/02_compile_textures.bat を利用）
3. このMODフォルダを autocompiler が監視できる場所（DSTの mods/ 配下）に置く
4. `bigportraits/` と `images/` にあるPNGが、同名の `.tex` と `.xml` に変換されるのを待つ
   - 例: `bigportraits/celica.png` → `bigportraits/celica.tex` + `bigportraits/celica.xml`

## うまくいったかのチェック
以下が存在すればOK:
- `bigportraits/celica.tex` と `bigportraits/celica.xml`
- `images/selectscreen_portraits/celica.tex` と `.../celica.xml`
- 4人分すべて同様

## 次の段階
- まず起動して「キャラ選択画面で落ちない」ことを確認
- スポーンして透明にならないか確認（このキットは Wilson の見た目を借りる設計）
