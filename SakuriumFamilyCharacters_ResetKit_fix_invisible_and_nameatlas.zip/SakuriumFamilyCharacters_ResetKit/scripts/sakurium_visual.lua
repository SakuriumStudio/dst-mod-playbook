local M = {}

-- “透明化”をまず潰すための、見た目借り用ユーティリティ。
-- ここでは Wilson の bank/build と “wilson_none” スキンを強制して、
-- player_common / skinner の上書きが入っても最終的に表示に戻す。

function M.ForceBorrowedLook(inst, base_prefab)
    base_prefab = base_prefab or "wilson"

    if inst ~= nil and inst.AnimState ~= nil then
        inst.AnimState:SetBank(base_prefab)
        inst.AnimState:SetBuild(base_prefab)
        -- キャラの持ち方の見た目（標準）
        inst.AnimState:Hide("ARM_carry")
        inst.AnimState:Show("ARM_normal")
    end

    if inst ~= nil and inst.components ~= nil and inst.components.skinner ~= nil then
        -- API が変わっても落ちないように pcall
        pcall(function()
            inst.components.skinner:SetSkinMode("normal_skin")
        end)
        pcall(function()
            inst.components.skinner:SetSkinName(base_prefab .. "_none")
        end)
    end
end

-- 初期化直後と、skinner が触った後にもう一度当て直す
function M.InstallBorrowedLookHooks(inst, base_prefab)
    inst:DoTaskInTime(0, function() M.ForceBorrowedLook(inst, base_prefab) end)
    inst:DoTaskInTime(0.5, function() M.ForceBorrowedLook(inst, base_prefab) end)
    inst:DoTaskInTime(1, function() M.ForceBorrowedLook(inst, base_prefab) end)

    -- 皮膚変更系のイベントが飛ぶ環境なら追従
    inst:ListenForEvent("ms_setskin", function() M.ForceBorrowedLook(inst, base_prefab) end)
    inst:ListenForEvent("setskin", function() M.ForceBorrowedLook(inst, base_prefab) end)
end

return M
