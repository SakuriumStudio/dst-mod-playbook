local MakePlayerCharacter = require "prefabs/player_common"
local Visual = require "sakurium_visual"

local assets = { }
local prefabs = { }

local start_inv = { }

local function common_postinit(inst)
    inst:AddTag("sakurium_family")
    -- 透明化回避: 既存キャラの見た目を借りる（まずはwilson固定）
    Visual.InstallBorrowedLookHooks(inst, "wilson")
end

local function master_postinit(inst)
    inst.soundsname = "wilson"
    inst.talker_path_override = "speech_wilson"

    -- ステータス（叩き台）
    -- HARURU: HP175 / HUN130 / SAN175 / DMG1.05 / SPD0.98
    inst.components.health:SetMaxHealth(175)
    inst.components.hunger:SetMax(130)
    inst.components.sanity:SetMax(175)
    
    inst.components.combat.damagemultiplier = 1.05
    inst.components.locomotor:SetExternalSpeedMultiplier(inst, "haruru_speed", 0.98)

    Visual.InstallBorrowedLookHooks(inst, "wilson")
end

return MakePlayerCharacter("haruru", prefabs, assets, common_postinit, master_postinit, start_inv)
