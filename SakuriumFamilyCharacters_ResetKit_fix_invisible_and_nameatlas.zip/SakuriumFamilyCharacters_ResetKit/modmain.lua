-- Sakurium Family Characters - Reset Kit (4 characters)
-- First run:
-- 1) Install "Don't Starve Mod Tools" (Steam Tools)
-- 2) Run tools\02_compile_textures.bat (starts autocompiler)
-- 3) Start DST with this mod enabled

PrefabFiles = {
    "kisana", "celica", "yuki", "haruru",
}

Assets = {
    Asset("IMAGE", "modicon.tex"),
    Asset("ATLAS", "modicon.xml"),
Asset("IMAGE", "images/saveslot_portraits/kisana.tex"),
Asset("ATLAS", "images/saveslot_portraits/kisana.xml"),
Asset("IMAGE", "images/selectscreen_portraits/kisana.tex"),
Asset("ATLAS", "images/selectscreen_portraits/kisana.xml"),
Asset("IMAGE", "images/selectscreen_portraits/kisana_silho.tex"),
Asset("ATLAS", "images/selectscreen_portraits/kisana_silho.xml"),
Asset("IMAGE", "bigportraits/kisana.tex"),
Asset("ATLAS", "bigportraits/kisana.xml"),
Asset("IMAGE", "images/map_icons/kisana.tex"),
Asset("ATLAS", "images/map_icons/kisana.xml"),
Asset("IMAGE", "images/avatars/avatar_kisana.tex"),
Asset("ATLAS", "images/avatars/avatar_kisana.xml"),
Asset("IMAGE", "images/avatars/avatar_ghost_kisana.tex"),
Asset("ATLAS", "images/avatars/avatar_ghost_kisana.xml"),
Asset("IMAGE", "images/avatars/self_inspect_kisana.tex"),
Asset("ATLAS", "images/avatars/self_inspect_kisana.xml"),
Asset("IMAGE", "images/names_kisana.tex"),
Asset("ATLAS", "images/names_kisana.xml"),
Asset("IMAGE", "images/names_gold_kisana.tex"),
Asset("ATLAS", "images/names_gold_kisana.xml"),
Asset("IMAGE", "images/saveslot_portraits/celica.tex"),
Asset("ATLAS", "images/saveslot_portraits/celica.xml"),
Asset("IMAGE", "images/selectscreen_portraits/celica.tex"),
Asset("ATLAS", "images/selectscreen_portraits/celica.xml"),
Asset("IMAGE", "images/selectscreen_portraits/celica_silho.tex"),
Asset("ATLAS", "images/selectscreen_portraits/celica_silho.xml"),
Asset("IMAGE", "bigportraits/celica.tex"),
Asset("ATLAS", "bigportraits/celica.xml"),
Asset("IMAGE", "images/map_icons/celica.tex"),
Asset("ATLAS", "images/map_icons/celica.xml"),
Asset("IMAGE", "images/avatars/avatar_celica.tex"),
Asset("ATLAS", "images/avatars/avatar_celica.xml"),
Asset("IMAGE", "images/avatars/avatar_ghost_celica.tex"),
Asset("ATLAS", "images/avatars/avatar_ghost_celica.xml"),
Asset("IMAGE", "images/avatars/self_inspect_celica.tex"),
Asset("ATLAS", "images/avatars/self_inspect_celica.xml"),
Asset("IMAGE", "images/names_celica.tex"),
Asset("ATLAS", "images/names_celica.xml"),
Asset("IMAGE", "images/names_gold_celica.tex"),
Asset("ATLAS", "images/names_gold_celica.xml"),
Asset("IMAGE", "images/saveslot_portraits/yuki.tex"),
Asset("ATLAS", "images/saveslot_portraits/yuki.xml"),
Asset("IMAGE", "images/selectscreen_portraits/yuki.tex"),
Asset("ATLAS", "images/selectscreen_portraits/yuki.xml"),
Asset("IMAGE", "images/selectscreen_portraits/yuki_silho.tex"),
Asset("ATLAS", "images/selectscreen_portraits/yuki_silho.xml"),
Asset("IMAGE", "bigportraits/yuki.tex"),
Asset("ATLAS", "bigportraits/yuki.xml"),
Asset("IMAGE", "images/map_icons/yuki.tex"),
Asset("ATLAS", "images/map_icons/yuki.xml"),
Asset("IMAGE", "images/avatars/avatar_yuki.tex"),
Asset("ATLAS", "images/avatars/avatar_yuki.xml"),
Asset("IMAGE", "images/avatars/avatar_ghost_yuki.tex"),
Asset("ATLAS", "images/avatars/avatar_ghost_yuki.xml"),
Asset("IMAGE", "images/avatars/self_inspect_yuki.tex"),
Asset("ATLAS", "images/avatars/self_inspect_yuki.xml"),
Asset("IMAGE", "images/names_yuki.tex"),
Asset("ATLAS", "images/names_yuki.xml"),
Asset("IMAGE", "images/names_gold_yuki.tex"),
Asset("ATLAS", "images/names_gold_yuki.xml"),
Asset("IMAGE", "images/saveslot_portraits/haruru.tex"),
Asset("ATLAS", "images/saveslot_portraits/haruru.xml"),
Asset("IMAGE", "images/selectscreen_portraits/haruru.tex"),
Asset("ATLAS", "images/selectscreen_portraits/haruru.xml"),
Asset("IMAGE", "images/selectscreen_portraits/haruru_silho.tex"),
Asset("ATLAS", "images/selectscreen_portraits/haruru_silho.xml"),
Asset("IMAGE", "bigportraits/haruru.tex"),
Asset("ATLAS", "bigportraits/haruru.xml"),
Asset("IMAGE", "images/map_icons/haruru.tex"),
Asset("ATLAS", "images/map_icons/haruru.xml"),
Asset("IMAGE", "images/avatars/avatar_haruru.tex"),
Asset("ATLAS", "images/avatars/avatar_haruru.xml"),
Asset("IMAGE", "images/avatars/avatar_ghost_haruru.tex"),
Asset("ATLAS", "images/avatars/avatar_ghost_haruru.xml"),
Asset("IMAGE", "images/avatars/self_inspect_haruru.tex"),
Asset("ATLAS", "images/avatars/self_inspect_haruru.xml"),
Asset("IMAGE", "images/names_haruru.tex"),
Asset("ATLAS", "images/names_haruru.xml"),
Asset("IMAGE", "images/names_gold_haruru.tex"),
Asset("ATLAS", "images/names_gold_haruru.xml"),
}

local STRINGS = GLOBAL.STRINGS

local function SetCharacterStrings(id, displayname, title, desc, quote)
    STRINGS.CHARACTER_TITLES[id] = title
    STRINGS.CHARACTER_NAMES[id] = displayname
    STRINGS.CHARACTER_DESCRIPTIONS[id] = desc
    STRINGS.CHARACTER_QUOTES[id] = quote
end

SetCharacterStrings(
    "kisana",
    "KISANA",
    "The Gentle One",
    "Placeholder stats (will be customized).",
    "\"We got this.\""
)

SetCharacterStrings(
    "celica",
    "CELICA",
    "The Planner",
    "Placeholder stats (will be customized).",
    "\"Let's make it clean.\""
)

SetCharacterStrings(
    "yuki",
    "YUKI",
    "The Calm One",
    "Placeholder stats (will be customized).",
    "\"Slow and steady.\""
)

SetCharacterStrings(
    "haruru",
    "HARURU",
    "The Spark",
    "Placeholder stats (will be customized).",
    "\"We can do it!\""
)


AddModCharacter("kisana", "FEMALE")
AddModCharacter("celica", "MALE")
AddModCharacter("yuki", "FEMALE")
AddModCharacter("haruru", "FEMALE")
