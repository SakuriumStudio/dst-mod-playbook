name = "Sakurium Family Characters (Reset Kit: kisana only)"
description = "One-character test (kisana). First-run requires compiling PNG -> TEX/XML via Mod Tools/autocompiler."
author = "SakuriumStudio"
version = "0.0.1-kisana"
api_version = 10
dst_compatible = true
all_clients_require_mod = true
client_only_mod = false

icon_atlas = "modicon.xml"
icon = "modicon.tex"

configuration_options = {}
